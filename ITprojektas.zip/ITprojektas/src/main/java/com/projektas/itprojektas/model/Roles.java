package com.projektas.itprojektas.model;

public enum Roles {
    PLACEHOLDER,
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_CONSULTANT;
}
