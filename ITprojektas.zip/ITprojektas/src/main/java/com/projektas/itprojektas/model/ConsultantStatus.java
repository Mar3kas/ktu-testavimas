package com.projektas.itprojektas.model;

public enum ConsultantStatus {
    PLACEHOLDER,
    FREE,
    OCCUPIED;
}
